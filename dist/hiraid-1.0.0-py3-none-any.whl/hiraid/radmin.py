#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (c) 2021 Hitachi Vantara, Inc. All rights reserved.
# Author: Darren Chambers <@Darren-Chambers>
# Author: Clive Meakin
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

import os
import json
import copy
import argparse
import pickletools
from hiraid.raidcom import Raidcom
from datetime import datetime


version = Raidcom.version

class Radmin():
    def __init__(self,raidcom):
        self.raidcom = raidcom

    def index(self,*args,**kwargs):
        start = datetime.now().strftime('%d-%m-%Y_%H.%M.%S')
        print(f"Start: {start}\nCan take a few minutes..")
        # Get pools
        self.raidcom.getpool(key='basic')
        # Ports
        ports = self.raidcom.getport()
        # All hostgroups
        hostgrps = self.raidcom.concurrent_gethostgrps(ports=ports.view.keys())
        # All hsds
        allhsds = [f"{port}-{gid}" for port in hostgrps.view for gid in hostgrps.view[port]['_GIDS']]
        # All port logins
        self.raidcom.concurrent_getportlogins(ports=ports.view.keys())
        # All hbawwns
        self.raidcom.concurrent_gethbawwns(portgids=allhsds)
        # All luns
        self.raidcom.concurrent_getluns(portgids=allhsds)
        # All associated ldevs
        ldevs = set([ self.raidcom.views['_ports'][port]['_GIDS'][gid]['_LUNS'][lun]['LDEV'] for port in self.raidcom.views['_ports'] for gid in self.raidcom.views['_ports'][port].get('_GIDS',{}) for lun in self.raidcom.views['_ports'][port]['_GIDS'][gid].get('_LUNS',{}) ])
        self.raidcom.concurrent_getldevs(ldevs)
        
        # Combine stats and view with desired ordering
        end = datetime.now().strftime('%d-%m-%Y_%H.%M.%S')
        output_view = { 'start':start, 'end':end, '_stats': copy.deepcopy(self.raidcom.stats) }
        output_view.update(self.raidcom.views)
        # Embed stats into the view
        self.raidcom.stats.update(self.raidcom.views)
        self.raidcom.views['_stats'] = self.raidcom.stats
        
        file = self.writejson(output_view)
        
        print(f"index: {file}")
        print(f"End: {end}")
        return type('index', (object,), {'view':output_view})()
        #self.printstats()
    
    def printstats(self):
        print(json.dumps(self.raidcom.stats,indent=4))

    def writejson(self,dict,dir="/var/tmp/"):
        file = f"{dir}{self.raidcom.serial}__{datetime.now().strftime('%d-%m-%Y_%H.%M.%S')}.json"
        with open(file,'w') as w:
            w.write(json.dumps(dict,indent=4))
        return file

    def getport(self,args):
        ports = self.raidcom.getport()
        return ports
    
    def getpool(self,args):
        pools = self.raidcom.getpool(key="basic")
        return pools

    def gethbawwn(self,args):
        portlogins = self.raidcom.getportlogin(**vars(args))
        hbawwns = self.raidcom.gethbawwn(**vars(args))
        for port in hbawwns.view:
            for gid in hbawwns.view[port]['_GIDS']:
                for wwn in hbawwns.view[port]['_GIDS'][gid]['_WWNS']:
                    if wwn.lower() in portlogins.view.get(port,{}).get('_PORT_LOGINS',[]):
                        hbawwns.view[port]['_GIDS'][gid]['_WWNS'][wwn]["_PORT_LOGIN"] = True
        #print(json.dumps(hbawwns.view,indent=4))
        return hbawwns

    def getportlogins(self,args):

        portlogins = self.raidcom.concurrent_getportlogins(**vars(args))        
        hostgrps = self.raidcom.concurrent_gethostgrps(ports=portlogins.view.keys())
        allhsds = [f"{port}-{gid}" for port in hostgrps.view for gid in hostgrps.view[port]['_GIDS']]
        hostwwns = self.raidcom.concurrent_gethbawwns(portgids=allhsds)
        
        for port in hostwwns.view:
            for gid in hostwwns.view[port]['_GIDS']:
                for wwn in hostwwns.view[port]['_GIDS'][gid].get('_WWNS',{}):
                    if wwn.lower() in portlogins.view[port]['_PORT_LOGINS']:
                        portlogins.view[port]['_PORT_LOGINS'][wwn.lower()]['_HOST_GRPS'] = portlogins.view[port]['_PORT_LOGINS'][wwn.lower()].get('HOST_GRPS',[])
                        root = hostwwns.view[port]['_GIDS'][gid]['_WWNS'][wwn]
                        fields = ('GID','GROUP_NAME','NICK_NAME')
                        data = {field:root[field] for field in fields}
                        portlogins.view[port]['_PORT_LOGINS'][wwn.lower()]['_HOST_GRPS'].append(data)
        #print(json.dumps(portlogins.view,indent=4))
        return portlogins

    def getldevs(self,args) -> json:
        ldevs = self.raidcom.concurrent_getldevs(**vars(args))
        #print(json.dumps(ldevs.view,indent=4))
        return ldevs

def main():

    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("-I", "--instance",  required=True, help="Specify the horcm instance")
    parent_parser.add_argument("-s", "--serial",    required=True, help="Specify the storage serial number")
    parent_parser.add_argument("-t", "--stats", action='store_true', help="Include statistics in output if available", required=False, default=False)
    parent_parser.add_argument("-x", "--nodata", action='store_true', help="Do not output data, usually specified along with -t option", required=False, default=False)

    parser = argparse.ArgumentParser(description=f"A raidcom wrapper utility to assist with maintaining Hitachi storage arrays")
    parser.add_argument('--version', action='version', version=f"%(prog)s {version}")

    subparsers = parser.add_subparsers(help="Subcommands", dest="subcommand", required=True)
    subparsers.add_parser('index', help="Index storage array resources - Operation can take several minutes (5+)", parents=[parent_parser])
    subparsers.add_parser('getport', help="Obtain a list of ports from the storage array.", parents=[parent_parser])

    parser_gethbawwn = subparsers.add_parser('gethbawwn', help="Obtain hba_wwn, gethbawwn -h for help", parents=[parent_parser])
    parser_gethbawwn.add_argument("-p", "--port", help="Specify the storage port e.g. cl1-a", required=True)
    parser_gethbawwn.add_argument("-g", "--gid", help="Specify the host group gid. Gid and host group name are mutually exclusive.", required=False)
    parser_gethbawwn.add_argument("-n", "--name", help="Host group name. Gid and host group name are mutually exclusive.", required=False)

    parser_getldevs = subparsers.add_parser('getldevs', help="Obtain ldev information.", parents=[parent_parser])
    parser_getldevs.add_argument("-l", "--ldev_ids", nargs="+", help="Specify a list of ldev_ids e.g. -l 1000 1001 1002", required=True)

    parser_getportlogins = subparsers.add_parser('getportlogins', help="Obtain wwns logged into the given port.", parents=[parent_parser])
    parser_getportlogins.add_argument("-p", "--ports", nargs="+", help="Specify a list of ports to obtain host wwn login information e.g. -p cl1-a cl2-a", required=True)

    subparsers.add_parser('getpool', help="Obtain pool information", parents=[parent_parser])
    

    args = parser.parse_args()

    storage = Raidcom(args.serial,args.instance)
    radmin = Radmin(storage)

    output = getattr(radmin, args.subcommand)(args)
    if not args.nodata:
        print(json.dumps(output.view,indent=4))
    if args.stats and hasattr(output,'stats'):
        print(json.dumps(output.stats))

    #print(vars(args))
    #cifscloak.checkstatus()
    #parser.exit(status=cifscloak.status['error'])

if __name__ == "__main__":
    main()
